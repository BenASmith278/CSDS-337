#include <iostream>
#include <llvm/Bitcode/BitcodeWriter.h>
#include <llvm/IR/IRBuilder.h>
#include <llvm/IR/LegacyPassManager.h>
#include <llvm/IR/LLVMContext.h>
#include <llvm/IR/Module.h>
#include <llvm/IR/Verifier.h>
#include <llvm/Transforms/Scalar.h>
#include <llvm/Transforms/Scalar/GVN.h>
#include <llvm/Transforms/Utils.h>

// Starter code for the assignment.
int main()
{

    // Step 1 - Setup LLVM module. Note exporting is continued below.
    llvm::LLVMContext context;              // Our base context. This is how we talk to LLVM.
    // TODO: CREATE MODULE HERE!!!

    // Step 1 - Export LLVM module.
    std::error_code err;                             // Error code from outstream, we can reuse this.
    llvm::raw_fd_ostream outLl("sampleMod.ll", err); // Open an output file.
    mod.print(outLl, nullptr);                       // Print LLVM assembly to the file.
    outLl.close();                                   // Close file to save resources.
    // TODO: WRITE THE .BC FILE HERE!!!

}
