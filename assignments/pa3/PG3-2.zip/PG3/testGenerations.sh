./run.sh
clang++ testGenerations.cpp sampleMod.bc -o testGenerations
./testGenerations