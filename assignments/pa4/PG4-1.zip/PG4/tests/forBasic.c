int printf(string fmt, ...);

int main()
{
    int i;
    for (i = 0; i < 8; i++)
    {
        printf("Loop Iteration: %d\n", i);
    }
    return 0;
}